<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FrontendGenerators extends Model
{
    protected $table = 'frontend_generators';

    protected $guarded = [];
}
