<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomBilingPlans extends Model
{
	protected $table = 'custom_biling_plans';
    protected $guarded = [];
}