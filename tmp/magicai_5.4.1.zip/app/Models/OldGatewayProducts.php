<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OldGatewayProducts extends Model
{
    protected $table = 'oldgatewayproducts';

    protected $guarded = [];
}
